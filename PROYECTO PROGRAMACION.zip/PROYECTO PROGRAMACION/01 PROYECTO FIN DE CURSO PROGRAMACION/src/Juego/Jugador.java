package Juego;

abstract class Jugador {
	String nombre;
	int puntuacion;
	
	public Jugador(String nombre, int puntuacion) {
		this.nombre = nombre;
		this.puntuacion = puntuacion;
	}

	abstract void crearJugador();
	
	public void sumarPunto() {
		this.puntuacion++;
	}
	
	public String getNombre() {
		return this.nombre;
	}
	
}
