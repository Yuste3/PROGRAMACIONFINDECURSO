package Juego;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class Ranking {
	File rankingJugadores;
	File rankingHistorico;
	Scanner scJugadores;
	Scanner scHistorico;
	FileWriter inputJugadores;
	FileWriter inputHistorico;
	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public Ranking() {
		this.rankingJugadores = new File("src/Juego/rankingJugadores");
		this.rankingHistorico = new File("src/Juego/rankingHistorico");
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void mostrarRankingJugadores() {
		actualizarRanking();
		String rJugadoresString = rankingJugadoresToString();
		JOptionPane.showMessageDialog(null, "EL RANKING ES EL SIGUIENTE: " + "\n" + "\n" + rJugadoresString, "RANKING JUGADORES", -1);
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public String rankingJugadoresToString() {
		String rJugadoresString = "";
		try {
			scJugadores = new Scanner(rankingJugadores);
//			scJugadores.useDelimiter(" ");
			while (scJugadores.hasNext()) {
//				String nombre = scJugadores.next();
//				String puntuacion = scJugadores.next();
				rJugadoresString = rJugadoresString + scJugadores.next() + " " + scJugadores.next() + "\n";
			}
			scJugadores.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return rJugadoresString;
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void actualizarRanking() {
		//Meto todo en un map para tener organizado a los jugadores con sus puntuaciones
		Map<String, Integer> jugadoresAUX = new HashMap<String, Integer>();
		try {
			scJugadores = new Scanner(rankingJugadores);
			while(scJugadores.hasNext()) {
				String nombreAUX = scJugadores.next();
				int puntuacionAUX = scJugadores.nextInt();
				jugadoresAUX.put(nombreAUX, puntuacionAUX);
			}
			scJugadores.close();
			//Vacio el ranking para escribir ahora todo el ranking pero con sus actualizaciones
			vaciarRankingJugadores();
			//Ordeno el ranking
			List<Map.Entry<String, Integer>> listaOrdenada = ordenarRankingJugadores(jugadoresAUX);
			for (Map.Entry<String, Integer> datos : listaOrdenada) {
				inputJugadores = new FileWriter(rankingJugadores, true);
				inputJugadores.write(datos.getKey() + " " + datos.getValue() + "\n");
				inputJugadores.close();
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void vaciarRankingJugadores() {
		try {
			inputJugadores = new FileWriter(rankingJugadores);
			inputJugadores.flush();
			inputJugadores.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public List<Map.Entry<String, Integer>> ordenarRankingJugadores(Map<String, Integer> jugadoresAUX) {
		List<Map.Entry<String, Integer>> listaOrdenada = new ArrayList<Map.Entry<String, Integer>>(jugadoresAUX.entrySet());
		listaOrdenada.sort(Map.Entry.comparingByValue(Comparator.reverseOrder()));
		return listaOrdenada;
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void mostrarRankingHistorico() {
		String rankingHistoricoString = actualizarRankingHistorico();
		JOptionPane.showMessageDialog(null, "El ranking Historico es el siguiente:" + "\n" + "\n" + rankingHistoricoString + "\n");
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public String actualizarRankingHistorico() {
		ArrayList<String> rankingHistoricoArray = new ArrayList<String>();
		int contadorHistorico = 0;
		String rankingHistoricoString = "";
		try {
			scHistorico = new Scanner(rankingHistorico);
			scHistorico.useDelimiter("\n");
			while (scHistorico.hasNext()) {
				if (contadorHistorico == 5) {
					rankingHistoricoArray.remove(0);
					rankingHistoricoArray.add(scHistorico.next() + "\n");
				} else {
					rankingHistoricoArray.add(scHistorico.next() + "\n");
					contadorHistorico++;
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		for (String datos : rankingHistoricoArray) {
			rankingHistoricoString = rankingHistoricoString + datos;
		}
		return rankingHistoricoString;
	}
}
