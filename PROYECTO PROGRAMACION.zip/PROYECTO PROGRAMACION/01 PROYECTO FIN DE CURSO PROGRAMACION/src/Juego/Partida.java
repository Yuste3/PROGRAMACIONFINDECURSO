package Juego;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class Partida {
	static boolean partidaFinaliza;
	private static int idPartidaActual = 0;
	boolean fueraSeleccion = false;
	private int idPartida;
	int numRondas;
	String tipoPartida;
	Jugador jugador1;
	Jugador jugador2;
	Jugador jugador3;
	Jugador jugador4;
	Jugador CPU1;
	Jugador CPU2;
	Jugador CPU3;
	Jugador CPU4;
	ArrayList<Jugador> arrayJugadores = new ArrayList<Jugador>();
	final File archivoJugadores = new File("src/Juego/rankingJugadores");
	final File archivoHistorico = new File("src/Juego/rankingHistorico");
	ArrayList<Jugador> arrayJugadoresPartida = new ArrayList<Jugador>();
	ArrayList<Preguntas> arrayPreguntasPartida = new ArrayList<Preguntas>();
	Scanner scHistorico;
	Scanner scJugadores;
	FileWriter inputJugadores;
	FileWriter inputHistorico;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public Partida(String tipoPartida) {
		this.tipoPartida = tipoPartida;
		try {
			scJugadores = new Scanner(archivoJugadores);
			while(scJugadores.hasNext()) {
				String nombre = scJugadores.next();
				int puntuacion = scJugadores.nextInt();
				Jugador jugador = new Persona(nombre, puntuacion);
				arrayJugadores.add(jugador);
			}
			scJugadores.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public int getPartidaid() {
		return this.idPartida;
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static void infoPartida() {
		JOptionPane.showMessageDialog(null, "Hay dos tipos de partida: Partida o Práctica" + "\n"
				+ "PARTIDA: Tiene 4 modos" + "\n" + "RAPIDA(3 Rondas)" + "\n" + "CORTA(5 Rondas)" + "\n" + "NORMAL(10 Rondas)" + "\n" + "LARGA(20 Rondas)" + "\n"
				+ "PRACTICA: Consiste en una practica de 1 solo jugador con el numero de rondas que se elijan");
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void jugarPartida() {
		partidaFinaliza = true;
		fueraSeleccion = false;
		if (fueraSeleccion == false) {
			seleccionJugadores();
		}
		if (fueraSeleccion == false) {
			seleccionPartida();
		}
		if (fueraSeleccion == false) {
			crearPreguntas();
			muestraPreguntas();
			if (this.tipoPartida.equals("Partida")) {
				if (partidaFinaliza) {
					asignaIdPartida();
					try {
						actualizaRankingJugadores();
						actualizaRankingHistorico();
					} catch (Exception e) {
						System.out.println(e);
					}
				}
			}
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//SELECCIONA LOS JUGADORES Y CPU QUE VAN A JUGAR LA PARTIDA
	public void seleccionJugadores() {
		if (this.tipoPartida.equals("Partida")) {
			//auxiliar y auxiliar1 son variables que solo se utilizan en este caso para hacer la conversion a int dado que no se puede convertir
			//de Object a int directamente, sino que tienes que pasar a String y despues a int		
			try {
				Object auxiliar = JOptionPane.showInputDialog(null, "Cuantos jugadores van a jugar?", "SELECCIONA EL NUMERO DE JUGADORES", JOptionPane.QUESTION_MESSAGE, null, new String[]{"0","1", "2", "3", "4"}, "0");
				String auxiliar1 = auxiliar.toString();
				int numeroJugadores = Integer.parseInt(auxiliar1);
				ArrayList<String> nombresJugadores = new ArrayList<String>();
				for (Jugador jugador : arrayJugadores) {
					nombresJugadores.add(jugador.getNombre());
				}
				nombresJugadores.add("CREAR JUGADOR");
				for (int i = 0; i < numeroJugadores; i++) {
					Object opcionesJugadores[] = nombresJugadores.toArray();
					Object eleccionJugador = JOptionPane.showInputDialog(null, "Que jugador quieres añadir a la partida?", "ELIGE UN JUGADOR", JOptionPane.QUESTION_MESSAGE, null, opcionesJugadores, null);
					if (eleccionJugador.equals(null) || eleccionJugador == null) {
						throw new Exception();
					} else {
						if ("CREAR JUGADOR".equals(eleccionJugador) == false) {
							for (Jugador jugador : arrayJugadores) {
								if (jugador.getNombre().equals(eleccionJugador)) {
									arrayJugadoresPartida.add(jugador);
									arrayJugadores.remove(jugador);
									nombresJugadores.remove(jugador.getNombre());
									break;
								}
							}
						} else {
							boolean existeJugador = false;
							String nombreJugador = "";
							String nombreJugadorSinControl = JOptionPane.showInputDialog(null, "Dime el nombre del jugador que quieres añadir (RECUERDA QUE NO PUEDE CONTENER ESPACIOS)");
							if (nombreJugadorSinControl.equals(null) || nombreJugadorSinControl == null) {
								throw new Exception();
							} else {
								if (nombreJugadorSinControl.contains(" ")) {
									String nombreJugadorSinEspacios[] = nombreJugadorSinControl.split(" ");
									nombreJugador = nombreJugadorSinEspacios[0];
								} else {
									nombreJugador = nombreJugadorSinControl;
								}
								try {
									scJugadores = new Scanner(archivoJugadores);
									while (scJugadores.hasNext()) {
										String nombre = scJugadores.next();
										if (nombre.equals(nombreJugador)) {
											existeJugador = true;
										}
									}
									scJugadores.close();
								} catch (Exception e) {
									System.out.println(e);
								}
								if(existeJugador == false) {
									if (nombreJugador == null || nombreJugador.equals(null)) {//Creo que por aqui nunca pasa
										i--;
									} else {
										Jugador jugador1 = new Persona(nombreJugador, 0);
										jugador1.crearJugador();
										arrayJugadoresPartida.add(jugador1);
									}
								} else {
									JOptionPane.showMessageDialog(null, "El jugador ya existe, no se puede volver a crear");
									i--;
								}
							}
						}
					}
				}
				if (numeroJugadores == 0) {
					try {
						int puntuacionCPU = 0;
						scHistorico = new Scanner(archivoHistorico);
						scHistorico.useDelimiter(" ");
						while (scHistorico.hasNext()) {
							String nombre = scHistorico.next();
							if (nombre.equalsIgnoreCase("CPU1") || nombre.equals("\r"+ "\n" + "CPU1")) {
								puntuacionCPU = scHistorico.nextInt();
							}
						}
						scHistorico.close();
						Jugador jugador = new CPU("CPU1", puntuacionCPU);
						arrayJugadoresPartida.add(jugador);
						JOptionPane.showMessageDialog(null, "Dado que no jugaran personas, se añade a CPU1");
					} catch (Exception e) {
						System.out.println("Cada linea del historico tiene que terminar en espacio, por eso salta esta excepcion.");
					}
				}
				if (numeroJugadores != 4) {
					int numeroCPU = 0;
					int quiereCPU = JOptionPane.showOptionDialog(null, "¿Quieres añadir CPU?", "DECIDE SI QUIERES AÑADIR CPU O NO", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, new String[] {"Si","No"}, null);
					if (quiereCPU == 0) {
						switch (numeroJugadores + 1) {
							case 1: {
								auxiliar = JOptionPane.showInputDialog(null, "¿Cuantas CPU quieres añadir?", "SELECCIONA EL NUMERO DE CPU", JOptionPane.QUESTION_MESSAGE, null, new String[] {"1","2","3"}, null);
								auxiliar1 = auxiliar.toString();
								numeroCPU = Integer.parseInt(auxiliar1);
								break;
							}
							case 2: {
								auxiliar = JOptionPane.showInputDialog(null, "¿Cuantas CPU quieres añadir?", "SELECCIONA EL NUMERO DE CPU", JOptionPane.QUESTION_MESSAGE, null, new String[] {"1","2"}, null);
								auxiliar1 = auxiliar.toString();
								numeroCPU = Integer.parseInt(auxiliar1);
								break;
							}
							case 3: {
								numeroCPU = 1;
								break;
							}
						}
						for (int i = 1; i <= numeroCPU; i++) {
							int puntuacionCPU = 0;
							try {
								scHistorico = new Scanner(archivoHistorico);
								scHistorico.useDelimiter(" ");
								while (scHistorico.hasNext()) {
									/////// A LA HORA DE INTRODUCIR NUEVOS DATOS DE UNA PARTIDA EN EL HISTORICO, LA LINEA TIENE QUE TERMINAR CON UN ESPACIO, SINO
									////// PUEDE SALTAR EXCEPCION
									String nombre = scHistorico.next();
									if (nombre.equalsIgnoreCase("CPU" + (i+1)) || nombre.equals("\r"+ "\n" + "CPU" + (i+1))) {
										puntuacionCPU = scHistorico.nextInt();
									}
								}
								scHistorico.close();
							} catch (Exception e) {
								System.out.println("Cada linea del historico tiene que terminar en espacio, por eso salta esta excepcion.");
							}
							Jugador jugador = new CPU("CPU" + (i+1), puntuacionCPU);
							arrayJugadoresPartida.add(jugador);
						}
					}
				}
			} catch (Exception e) {
				arrayJugadoresPartida.clear();
				fueraSeleccion = true;
			}
		} else {//ENTRENAMIENTO
			try {
				int numeroJugadores = 1;
				ArrayList<String> nombresJugadores = new ArrayList<String>();
				for (Jugador jugador : arrayJugadores) {
					nombresJugadores.add(jugador.getNombre());
				}
				nombresJugadores.add("CREAR JUGADOR");
				for (int i = 0; i < numeroJugadores; i++) {
					Object opcionesJugadores[] = nombresJugadores.toArray();
					Object eleccionJugador = JOptionPane.showInputDialog(null, "Que jugador quieres añadir a la partida?", "ELIGE UN JUGADOR", JOptionPane.QUESTION_MESSAGE, null, opcionesJugadores, null);
					if (eleccionJugador.equals(null) || eleccionJugador == null) {
						throw new Exception();
					} else {
						if ("CREAR JUGADOR".equals(eleccionJugador) == false) {
							for (Jugador jugador : arrayJugadores) {
								if (jugador.getNombre().equals(eleccionJugador)) {
									arrayJugadoresPartida.add(jugador);
									arrayJugadores.remove(jugador);
									nombresJugadores.remove(jugador.getNombre());
									break;
								}
							}
						} else {
							boolean existeJugador = false;
							String nombreJugador = "";
							String nombreJugadorSinControl = JOptionPane.showInputDialog(null, "Dime el nombre del jugador que quieres añadir (RECUERDA QUE NO PUEDE CONTENER ESPACIOS)");
							if (nombreJugadorSinControl.equals(null) || nombreJugadorSinControl == null) {
								throw new Exception();
							} else {
								if (nombreJugadorSinControl.contains(" ")) {
									String nombreJugadorSinEspacios[] = nombreJugadorSinControl.split(" ");
									nombreJugador = nombreJugadorSinEspacios[0];
								} else {
									nombreJugador = nombreJugadorSinControl;
								}
								try {
									scJugadores = new Scanner(archivoJugadores);
									while (scJugadores.hasNext()) {
										String nombre = scJugadores.next();
										if (nombre.equals(nombreJugador)) {
											existeJugador = true;
										}
									}
									scJugadores.close();
								} catch (Exception e) {
									System.out.println(e);
								}
								if(existeJugador == false) {
									if (nombreJugador == null || nombreJugador.equals(null)) {//Creo que por aqui nunca pasa
										i--;
									} else {
										Jugador jugador1 = new Persona(nombreJugador, 0);
										jugador1.crearJugador();
										arrayJugadoresPartida.add(jugador1);
									}
								} else {
									JOptionPane.showMessageDialog(null, "El jugador ya existe, no se puede volver a crear");
									i--;
								}
							}
						}
					}
				}
			} catch (Exception e) {
				arrayJugadoresPartida.clear();
				fueraSeleccion = true;
			}
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//DURACION DE LA PARTIDA (SI ES PRACTICA PUEDE ELEGIR EL NUMERO DE RONDAS)
	public void seleccionPartida() {
		try {
			if (this.tipoPartida.equals("Partida")) {
				String tipoPartida = "RAPIDA == 3 rondas" + "\n" + "CORTA == 5 rondas" + "\n" + "NORMAL == 10 rondas" + "\n" + "LARGA == 20 rondas";
				int partidaElegida = JOptionPane.showOptionDialog(null, "¿Que tipo de partida quieres jugar?" + "\n" + tipoPartida, "ELIGE TIPO DE PARTIDA", JOptionPane.YES_NO_CANCEL_OPTION, -1, null, new String[] {"RAPIDA","CORTA","NORMAL","LARGA"}, null);
				if (partidaElegida == -1) {
					throw new Exception();
				} else {
					switch (partidaElegida) {
						case 0: {
							this.numRondas = 3;
							break;
						}
						case 1: {
							this.numRondas = 5;
							break;
						}
						case 2: {
							this.numRondas = 10;
							break;
						}
						case 3: {
							this.numRondas = 20;
							break;
						}
					}
				}
			} else {
					String tipoPartida = JOptionPane.showInputDialog(null, "Durante cuantas rondas vas a querer practicar? (Introduce un numero)");
					this.numRondas = Integer.parseInt(tipoPartida);
			}
		} catch (Exception e) {
			arrayJugadoresPartida.clear();
			fueraSeleccion = true;
		}
	}
	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void asignaIdPartida() {
		idPartidaActual++;
		this.idPartida = idPartidaActual;
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void actualizaRankingJugadores() {
		HashMap<String, Integer> jugadoresAUX = new HashMap<String, Integer>();
		try {
			scJugadores = new Scanner(archivoJugadores);
			while (scJugadores.hasNext()) {
				String nombreAUX = scJugadores.next();
				int puntuacionAUX = scJugadores.nextInt();
				for (Jugador jugador : arrayJugadoresPartida) {
					if (jugador.getNombre().equals(nombreAUX)) {
						puntuacionAUX = jugador.puntuacion;
					}
					jugadoresAUX.put(nombreAUX, puntuacionAUX);
				}
			}
			scJugadores.close();
			vaciarRankingJugadores();
			inputJugadores = new FileWriter(archivoJugadores, true);
			for (String nombre : jugadoresAUX.keySet()) {
				inputJugadores.write(nombre + " " + jugadoresAUX.get(nombre) + "\n");
			}
			inputJugadores.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void vaciarRankingJugadores() {
		try {
			inputJugadores = new FileWriter(archivoJugadores);
			inputJugadores.flush();
			inputJugadores.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void crearPreguntas() {
		for (int i = 0; i < this.numRondas/*2*/; i++) {
			for (Jugador jugador : arrayJugadoresPartida) {
				int numRandom = (int) ((Math.random()*3) + 1);
				if (numRandom == 1) {
					Preguntas pregunta = new PreguntaMates((int) ((Math.random()*(7-3+1)) + 3), jugador);
					arrayPreguntasPartida.add(pregunta);
				} else if(numRandom == 2) {
					Preguntas pregunta = new PreguntaIngles((int) ((Math.random()*1000) + 1), jugador);
					arrayPreguntasPartida.add(pregunta);
				} else {
					Preguntas pregunta = new PreguntaLetras((int) ((Math.random()*85220) + 1), jugador);
					arrayPreguntasPartida.add(pregunta);
				}
			}
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void muestraPreguntas() {
		for (Preguntas pregunta : arrayPreguntasPartida) {
			if (partidaFinaliza)
			pregunta.generarPregunta();
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void actualizaRankingHistorico() {
		try {
			inputHistorico = new FileWriter(archivoHistorico, true);
			for (Jugador jugador : arrayJugadoresPartida) {
				inputHistorico.write(jugador.nombre + " " + jugador.puntuacion + " ");
			}
			inputHistorico.write("\n");
			inputHistorico.close();
		} catch (Exception e) {
			System.out.println("Esta linea no se deberia de ejecutar nunca, si se ejecuta es por: " + e);
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}
