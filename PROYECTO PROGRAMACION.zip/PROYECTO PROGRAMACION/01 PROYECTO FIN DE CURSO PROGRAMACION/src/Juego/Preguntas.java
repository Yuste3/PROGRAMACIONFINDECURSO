package Juego;

abstract class Preguntas {
	int numero;
	String respuestaEsperada;
	Jugador jugadorPregunta;
	
	public Preguntas(int numero, Jugador jugadorPregunta) {
//		System.out.println("Entro al constructor de Preguntas");
		this.numero = numero;
		this.respuestaEsperada = "";
		this.jugadorPregunta = jugadorPregunta;
	}
	
	abstract void generarPregunta();
	abstract void mostrarPregunta();
	
}
