package Juego;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class Persona extends Jugador{
	
	File rankingJugadores;
	File rankingHistorico;
	FileWriter inputJugadores;
	FileWriter inputHistorico;
	Scanner scJugadores;
	Scanner scHistorico;
	
	public Persona(String nombre, int puntuacion) {
		super(nombre, puntuacion);
		rankingJugadores = new File("src/Juego/rankingJugadores");
		rankingHistorico = new File("src/Juego/rankingHistorico");
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void crearJugador() {
		boolean existeJugador = buscarSiExiste();
		if (existeJugador) {
			JOptionPane.showMessageDialog(null, "Lo siento, el jugador ya existe, no se puede crear uno nuevo");
		} else {
			try {
				inputJugadores = new FileWriter(rankingJugadores, true);
				inputJugadores.write(super.nombre + " " + super.puntuacion + "\n");
				inputJugadores.close();
				JOptionPane.showMessageDialog(null, "El jugador " + super.nombre + " ha sido creado correctamente");
			} catch (IOException e) {
				System.out.println(e);
			}
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	void eliminarJugador() {
		boolean existeJugador = buscarSiExiste();
		if (existeJugador == false) {
			JOptionPane.showMessageDialog(null, "Lo siento, el jugador que has intentado eliminar no existe");
		} else {
			try {
				Map<String, Integer> jugadoresAUX = new HashMap<String, Integer>();
				scJugadores = new Scanner(rankingJugadores);
				while (scJugadores.hasNext()) {
					String nombreAUX = scJugadores.next();
					int puntuacionAUX = scJugadores.nextInt();
					if (nombreAUX.equalsIgnoreCase(super.nombre)) {
						JOptionPane.showMessageDialog(null, "El jugador " + super.nombre + " se ha eliminado correctamente");
					} else {
						jugadoresAUX.put(nombreAUX, puntuacionAUX);
					}
				}
				scJugadores.close();
				vaciarRankingJugadores();
				for (String nombre : jugadoresAUX.keySet()) {
					try {
						inputJugadores = new FileWriter(rankingJugadores,true);
						inputJugadores.write(nombre + " " + jugadoresAUX.get(nombre) + "\n");
						inputJugadores.close();
					} catch (Exception e) {
						System.out.println(e);
					}
				}
			} catch (IOException e) {
				System.out.println(e);
			}
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	private boolean buscarSiExiste() {
		boolean existeJugador = false;
		
		try {
			scJugadores = new Scanner(rankingJugadores);
		} catch (FileNotFoundException e) {
			System.out.println(e);
		}
		
		while(scJugadores.hasNext()) {
			if(scJugadores.next().equalsIgnoreCase(super.nombre)) {
				existeJugador = true;
			}
//			scJugadores.next();
		}
		scJugadores.close();
		return existeJugador;
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void vaciarRankingJugadores() {
		try {
			inputJugadores = new FileWriter(rankingJugadores);
			inputJugadores.flush();
			inputJugadores.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public List<Map.Entry<String, Integer>> ordenarRankingJugadores(Map<String, Integer> jugadoresAUX) {
		List<Map.Entry<String, Integer>> listaOrdenada = new ArrayList<>(jugadoresAUX.entrySet());
		listaOrdenada.sort(Map.Entry.comparingByValue(Comparator.reverseOrder()));
		return listaOrdenada;
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void sumarPunto() {
		super.sumarPunto();
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
}