package Juego;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class PreguntaLetras extends Preguntas{

	Scanner sc;
	ArrayList<Character> palabraArray;
	String preguntaString;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public PreguntaLetras(int numeroPalabra, Jugador jugadorPregunta) {
		super(numeroPalabra, jugadorPregunta);
		File archivo = new File("src/Juego/diccionario");
		try {
			sc = new Scanner(archivo);
		} catch (FileNotFoundException e) {
			System.out.println(e);
		}
		this.palabraArray = new ArrayList<Character>();
		this.preguntaString = "";
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	void generarPregunta() {
		JOptionPane.showMessageDialog(null, "Pregunta de LETRAS para " + super.jugadorPregunta.nombre + "\n" + "\n" + "INFORMACION: Se te mostrará una palabra con algunas de sus letras ocultas. Solo tendras una oportunidad para adivinarla, asique piensa bien");
		
		if (super.jugadorPregunta instanceof CPU) {
			JOptionPane.showMessageDialog(null, "El jugador " + super.jugadorPregunta.nombre + " ha fallado la pregunta");
		} else if(super.jugadorPregunta instanceof Persona) {
			seleccionarPalabra();
			conteoDeLetras();
			ocultarLetras();
			preguntaString();
			mostrarPregunta();
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void seleccionarPalabra() {
		for (int i = 0; i < super.numero; i++) {
			if (i == (super.numero-1)) {
				super.respuestaEsperada = sc.next();
				sc.close();
			} else  {
				sc.next();
			}
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void conteoDeLetras() {
		for (int i = 0; i < super.respuestaEsperada.length(); i++) {
			this.palabraArray.add(super.respuestaEsperada.charAt(i));
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void ocultarLetras() {
		int proporcion = (super.respuestaEsperada.length()) / 3;
		for (int i = 0; i < proporcion; i++) {
			int numeroParaOcultar = (int) (Math.random() * super.respuestaEsperada.length());
			if (palabraArray.get(numeroParaOcultar).equals('*')) {
				i--;
			} else {
				palabraArray.set(numeroParaOcultar, '*');
			}
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void preguntaString() {
		for (Character p : palabraArray) {
			preguntaString = preguntaString + p;
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	void mostrarPregunta() {
		try {
			String respuestaIntroducida = JOptionPane.showInputDialog(null, "La palabra a resolver es :" + "\n" + preguntaString);
			if (respuestaIntroducida.equalsIgnoreCase(super.respuestaEsperada)) {
				JOptionPane.showMessageDialog(null, "Has acertado la pregunta");
				super.jugadorPregunta.puntuacion++;
			} else {
				JOptionPane.showMessageDialog(null, "Lo siento, la respuesta es incorrecta, la respuesta correcta era: " + super.respuestaEsperada);
			}
		} catch (Exception e) {
			int opcion = JOptionPane.showOptionDialog(null, "¿Quieres salir de la partida? (NO SE GUARDARA EL PROGRESO DE ESTA)", "SALIR DE LA PARTIDA", JOptionPane.YES_NO_CANCEL_OPTION, -1, null, new String[] {"Si","No"}, null);
			if (opcion == 0) {
				Partida.partidaFinaliza = false;
			} else {
			mostrarPregunta();
			}
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
}


















//		int contadorPalabras1 = 0, contadorPalabras2 = 0, contadorPalabras3 = 0;
//		while (sc.hasNext()) {
//			String pruebaPalabra = sc.next();
//			if (pruebaPalabra.length() == 1) {
//				contadorPalabras1++;
//			} else if(pruebaPalabra.length() == 2) {
//				contadorPalabras2++;
//			} else if(pruebaPalabra.length() == 3) {
//				contadorPalabras3++;
//			}
//		}
//		System.out.println(contadorPalabras1 + " palabras con 1 letra");
//		System.out.println(contadorPalabras2 + " palabras con 2 letras");
//		System.out.println(contadorPalabras3 + " palabras con 3 letras");