package Juego;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class Juego {
	static int seleccion;
	public static void main(String[] args) {
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//		CREACION DE VARIABLES	
		ArrayList<Jugador> arrayJugadores = new ArrayList<Jugador>();
		Ranking rankingJugadores = new Ranking();
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		final File archivoJugadores = new File("src/Juego/rankingJugadores");
		try {
			Scanner scJugadores = new Scanner(archivoJugadores);
			while(scJugadores.hasNext()) {
				String nombre = scJugadores.next();
				int puntuacion = scJugadores.nextInt();
				Jugador jugador = new Persona(nombre, puntuacion);
				arrayJugadores.add(jugador);
			}
			scJugadores.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		
		seleccion = Menu.menuJuego();
		while ((seleccion != 4 && seleccion != -1)) {
			if (seleccion == 0) {
				
				int opcionPartida = JOptionPane.showOptionDialog(null, "Dime que tipo de partida que quieres jugar", "SELECCIONA TIPO DE PARTIDA", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, new String[]{"Partida", "Práctica", "Info"}, null);
				switch (opcionPartida) {
					case 0: {
						JOptionPane.showMessageDialog(null, "Has elegido partida");
						String tipoPartida = "Partida";
						Partida partida = new Partida(tipoPartida);
						partida.jugarPartida();
						seleccion = Menu.menuJuego();
						break;
					}
					case 1: {
						JOptionPane.showMessageDialog(null, "Has elegido Practica");
						String tipoPartida = "Practica";
						Partida partida = new Partida(tipoPartida);
						partida.jugarPartida();
						seleccion = Menu.menuJuego();
						break;
					}
					case 2: {
//						JOptionPane.showMessageDialog(null, "Has elegido info");
						Partida.infoPartida();
						seleccion = Menu.menuJuego();
						break;
					}
					default: {
						seleccion = Menu.menuJuego();
						break;
					}
				}
				
			} else if (seleccion == 1) {
				
				rankingJugadores.mostrarRankingJugadores();
				seleccion = Menu.menuJuego();
				
			} else if (seleccion == 2) {
				
				rankingJugadores.mostrarRankingHistorico();
				seleccion = Menu.menuJuego();
				
			} else if (seleccion == 3) {
				int nCrearEliminar = Menu.crearEliminarOpcion();
				if (nCrearEliminar == 0) {
					String nombreJugador = JOptionPane.showInputDialog(null, "Dime el nombre del jugador que quieres añadir (RECUERDA QUE NO PUEDE TENER ESPACIOS EN BLANCO)8");
					if (nombreJugador == null || nombreJugador.equals(null) || nombreJugador.equals("") || nombreJugador.equals(" ")) {
						seleccion = Menu.menuJuego();
					} else {
						Jugador jugador1 = new Persona(nombreJugador, 0);
						jugador1.crearJugador();
						seleccion = Menu.menuJuego();
					}
				} else if (nCrearEliminar == 1) {
					String nombreJugador = JOptionPane.showInputDialog(null, "Dime el nombre del jugador que quieres eliminar");
					if (nombreJugador == null) {
						seleccion = Menu.menuJuego();
					} else {
						int confirmarEliminar = Menu.confirmarEliminar(nombreJugador);
						if (confirmarEliminar == 0) {
							Jugador jugador2 = new Persona(nombreJugador, 0);
							((Persona) jugador2).eliminarJugador();
							seleccion = Menu.menuJuego();
						} else {
							seleccion = Menu.menuJuego();
						}
					}
				} else if (nCrearEliminar == 2) {
					String nombresJugadores = "";
					for (Jugador jugador : arrayJugadores) {
						nombresJugadores = nombresJugadores + jugador.nombre + "\n";
					}
					JOptionPane.showMessageDialog(null, "JUGADORES RESGISTRADOS EN EL SISTEMA:" + "\n" + "\n" + nombresJugadores);
					seleccion = Menu.menuJuego();
				} else if (nCrearEliminar == -1) {
					seleccion = Menu.menuJuego();
				}
			}
		}
	}
}
