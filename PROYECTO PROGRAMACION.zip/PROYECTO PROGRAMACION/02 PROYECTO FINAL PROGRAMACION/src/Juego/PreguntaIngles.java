package Juego;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class PreguntaIngles extends Preguntas{
	int numeroPalabra;
	Scanner sc;
	String preguntaAtleatoria, opcion1, opcion2, opcion3;
	ArrayList<String> preguntaRandomizada;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public PreguntaIngles(int numeroPregunta, Jugador jugadorPregunta) {
		super(numeroPregunta, jugadorPregunta);
		File archivo = new File("src/Juego/ingles");
		try {
			sc = new Scanner(archivo);
		} catch (FileNotFoundException e) {
			System.out.println(e);
		}
		this.preguntaAtleatoria = "";
		this.opcion1 = "";
		this.opcion2 = "";
		this.opcion3 = "";
		this.preguntaRandomizada = new ArrayList<String>();
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	void generarPregunta() {
		JOptionPane.showMessageDialog(null, "Pregunta de INGLES para " + super.jugadorPregunta.nombre + "\n" + "\n" + "INFORMACIÓN: Se te mostrará una pregunta en Ingles con 4 opciones. Selecciona la correcta para sumar punto");
		HashSet<String> sacoDeOpciones = new HashSet<String>();
		seleccionarPregunta();
		sacoDeOpciones = sacoPreguntas();
		mezclarOpciones(sacoDeOpciones);
		mostrarPregunta();
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void seleccionarPregunta() {
		sc.useDelimiter("\n");
		for (int i = 0; i < super.numero; i++) {
			if (i == (super.numero -1)) {
				this.preguntaAtleatoria = sc.next();
				super.respuestaEsperada = sc.next();
				this.opcion1 = sc.next();
				this.opcion2 = sc.next();
				this.opcion3 = sc.next();
			} else {
				for (int j = 0; j < 5; j++) {
					sc.next();
				}
			}
		}
//		System.out.println();
//		System.out.print(this.preguntaAtleatoria);
//		System.out.print(super.respuestaEsperada);
//		System.out.print(this.opcion1);
//		System.out.print(this.opcion2);
//		System.out.print(this.opcion3);
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public HashSet<String> sacoPreguntas() {
		HashSet<String> sacoDeOpciones = new HashSet<String>();
		sacoDeOpciones.add(super.respuestaEsperada);
		sacoDeOpciones.add(opcion1);
		sacoDeOpciones.add(opcion2);
		sacoDeOpciones.add(opcion3);
//		System.out.println();
//		for (String p : sacoDeOpciones) {
//			System.out.println(p);
//		}
		return sacoDeOpciones;
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void mezclarOpciones(HashSet<String> sacoDeOpciones) {
		preguntaRandomizada.addAll(sacoDeOpciones);
		Collections.shuffle(preguntaRandomizada);
//		int opcion = 0;
//		for (String p : preguntaRandomizada) {
//			opcion++;
//			System.out.print("Opcion " + opcion + ": " + p);
//		}
		
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	void mostrarPregunta() {
		String opcionesJPane[] = {preguntaRandomizada.get(0),preguntaRandomizada.get(1),preguntaRandomizada.get(2),preguntaRandomizada.get(3)};
		String preguntaString = crearStringPregunta();
		if (super.jugadorPregunta instanceof CPU) {
			int respuestaRandomCPU = (int) (Math.random()*3);
			switch(respuestaRandomCPU) {
				case 0:
					if (preguntaRandomizada.get(0).equals(super.respuestaEsperada)) {
						JOptionPane.showMessageDialog(null, "El jugador " + super.jugadorPregunta.nombre + " ha acertado la pregunta");
						super.jugadorPregunta.puntuacion++;
					} else {
						JOptionPane.showMessageDialog(null, "El jugador " + super.jugadorPregunta.nombre + " ha fallado la pregunta");
					}
					break;
				case 1:
					if (preguntaRandomizada.get(1).equals(super.respuestaEsperada)) {
						JOptionPane.showMessageDialog(null, "El jugador " + super.jugadorPregunta.nombre + " ha acertado la pregunta");
						super.jugadorPregunta.puntuacion++;
					} else {
						JOptionPane.showMessageDialog(null, "El jugador " + super.jugadorPregunta.nombre + " ha fallado la pregunta");
					}
					break;
				case 2:
					if (preguntaRandomizada.get(2).equals(super.respuestaEsperada)) {
						JOptionPane.showMessageDialog(null, "El jugador " + super.jugadorPregunta.nombre + " ha acertado la pregunta");
						super.jugadorPregunta.puntuacion++;
					} else {
						JOptionPane.showMessageDialog(null, "El jugador " + super.jugadorPregunta.nombre + " ha fallado la pregunta");
					}
					break;
				case 3:
					if (preguntaRandomizada.get(3).equals(super.respuestaEsperada)) {
						JOptionPane.showMessageDialog(null, "El jugador " + super.jugadorPregunta.nombre + " ha acertado la pregunta");
						super.jugadorPregunta.puntuacion++;
					} else {
						JOptionPane.showMessageDialog(null, "El jugador " + super.jugadorPregunta.nombre + " ha fallado la pregunta");
					}
					break;		
			}
		} else if(super.jugadorPregunta instanceof Persona) {
			int numeroPane = JOptionPane.showOptionDialog(null, preguntaString, "PREGUNTA DE INGLES", JOptionPane.DEFAULT_OPTION, -1, null, opcionesJPane, opcionesJPane);
			switch(numeroPane) {
				case -1:
					int opcion = JOptionPane.showOptionDialog(null, "¿Quieres salir de la partida? (NO SE GUARDARA EL PROGRESO DE ESTA)", "SALIR DE LA PARTIDA", JOptionPane.YES_NO_CANCEL_OPTION, -1, null, new String[] {"Si","No"}, null);
					if (opcion == 0) {
						Partida.partidaFinaliza = false;
					} else {
					mostrarPregunta();
					}
					break;
				case 0:
					if (preguntaRandomizada.get(0).equals(super.respuestaEsperada)) {
						JOptionPane.showMessageDialog(null, "Has acertado, ganas punto");
						super.jugadorPregunta.puntuacion++;
					} else {
						JOptionPane.showMessageDialog(null, "Lo siento, la respuesta es incorrecta, la respuesta correcta era: " + super.respuestaEsperada);
					}
					break;
				case 1:
					if (preguntaRandomizada.get(1).equals(super.respuestaEsperada)) {
						JOptionPane.showMessageDialog(null, "Has acertado, ganas punto");
						super.jugadorPregunta.puntuacion++;
					} else {
						JOptionPane.showMessageDialog(null, "Lo siento, la respuesta es incorrecta, la respuesta correcta era: " + super.respuestaEsperada);
					}
					break;
				case 2:
					if (preguntaRandomizada.get(2).equals(super.respuestaEsperada)) {
						JOptionPane.showMessageDialog(null, "Has acertado, ganas punto");
						super.jugadorPregunta.puntuacion++;
					} else {
						JOptionPane.showMessageDialog(null, "Lo siento, la respuesta es incorrecta, la respuesta correcta era: " + super.respuestaEsperada);
					}
					break;
				case 3:
					if (preguntaRandomizada.get(3).equals(super.respuestaEsperada)) {
						JOptionPane.showMessageDialog(null, "Has acertado, ganas punto");
						super.jugadorPregunta.puntuacion++;
					} else {
						JOptionPane.showMessageDialog(null, "Lo siento, la respuesta es incorrecta, la respuesta correcta era: " + super.respuestaEsperada);
					}
					break;		
			}
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	private String crearStringPregunta() {
		String preguntaString = this.preguntaAtleatoria + "\n";
		for (String p : preguntaRandomizada) {
			preguntaString = preguntaString + p + "\n";
		}		
		return preguntaString;
	}


}
