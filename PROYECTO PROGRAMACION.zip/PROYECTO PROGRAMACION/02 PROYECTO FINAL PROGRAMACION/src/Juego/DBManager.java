package Juego;


import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.sql.ResultSet;


public class DBManager {

    // Conexión a la base de datos
    private static Connection conn = null;

    // Configuración de la conexión a la base de datos
    private static final String DB_HOST = "localhost";
    private static final String DB_PORT = "3307";	////UTILIZO EL PUERTO 3307 PORQUE ES DONDE TENGO CONFIGURADO YO EL XAMP
    private static final String DB_NAME = "juegoDamGGM";
    private static final String DB_URL = "jdbc:mysql://" + DB_HOST + ":" + DB_PORT + "/" + DB_NAME + "?serverTimezone=UTC";
    private static final String DB_USER = "dam2223";
    private static final String DB_PASS = "dam2223";
    private static final String DB_MSQ_CONN_OK = "CONEXIÓN CORRECTA";
    private static final String DB_MSQ_CONN_NO = "ERROR EN LA CONEXIÓN";

    // Configuración de la tabla RANKING
    private static final String DB_CLI_RANKING = "ranking";
    private static final String DB_CLI_SELECT_ALL_RANKING = "SELECT * FROM " + DB_CLI_RANKING;
    private static final String DB_CLI_NICKNAME = "nickname";
    private static final String DB_CLI_PUNTUACION = "puntuacion";
//    private static final String DB_CLI_FECN = "fechanac";
    private static final String DB_CLI_SELECT_NICKNAME_RANKING = "SELECT " + DB_CLI_NICKNAME + " FROM " + DB_CLI_RANKING;
    private static final String DB_CLI_SELECT_PUNTUACION_RANKING = "SELECT " + DB_CLI_PUNTUACION + " FROM " + DB_CLI_RANKING;
    
    
    
    
    //Configuración de la tabla HISTORICO
    private static final String DB_CLI_HISTORICO = "historico";
    private static final String DB_CLI_SELECT_ALL_HISTORICO = "SELECT * FROM " + DB_CLI_HISTORICO;
    private static final String DB_CLI_IDPARTIDA = "id_partida";
    private static final String DB_CLI_SELECT_NICKNAME_HISTORICO = "SELECT " + DB_CLI_NICKNAME + " FROM " + DB_CLI_HISTORICO;
    private static final String DB_CLI_SELECT_PUNTUACION_HISTORICO = "SELECT " + DB_CLI_PUNTUACION + " FROM " + DB_CLI_HISTORICO;
    private static final String DB_CLI_SELECT_NICK_PUNTUACION_HISTORICO = "SELECT " + DB_CLI_NICKNAME + "," + DB_CLI_PUNTUACION + " FROM " + DB_CLI_HISTORICO;

    //////////////////////////////////////////////////
    // MÉTODOS DE CONEXIÓN A LA BASE DE DATOS
    //////////////////////////////////////////////////
    ;
    
    /**
     * Intenta cargar el JDBC driver.
     * @return true si pudo cargar el driver, false en caso contrario
     */
    public static boolean loadDriver() {
        try {
            System.out.print("Cargando Driver...");
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("OK!");
            return true;
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
            return false;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    /**
     * Intenta conectar con la base de datos.
     *
     * @return true si pudo conectarse, false en caso contrario
     */
    public static boolean connect() {
        try {
            System.out.print("Conectando a la base de datos...");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
            System.out.println("OK!");
            return true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    /**
     * Comprueba la conexión y muestra su estado por pantalla
     *
     * @return true si la conexión existe y es válida, false en caso contrario
     */
    public static boolean isConnected() {
        // Comprobamos estado de la conexión
        try {
            if (conn != null && conn.isValid(0)) {
                System.out.println(DB_MSQ_CONN_OK);
                return true;
            } else {
                return false;
            }
        } catch (SQLException ex) {
            System.out.println(DB_MSQ_CONN_NO);
            ex.printStackTrace();
            return false;
        }
    }

    /**
     * Cierra la conexión con la base de datos
     */
    public static void close() {
        try {
            System.out.print("Cerrando la conexión...");
            conn.close();
            System.out.println("OK!");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    //////////////////////////////////////////////////
    // MÉTODOS DE TABLA PERSONAS
    //////////////////////////////////////////////////
    ;
    
    // Devuelve 
    // Los argumentos indican el tipo de ResultSet deseado
    /**
     * Obtiene toda la tabla Persona de la base de datos
     */
    public static ResultSet getTablaRanking(int resultSetType, int resultSetConcurrency) throws SQLException {
       
    	   try {
               Statement stmt = conn.createStatement(resultSetType, resultSetConcurrency);
               ResultSet rs = stmt.executeQuery(DB_CLI_SELECT_ALL_RANKING + " ORDER BY " + DB_CLI_PUNTUACION + " DESC");
               //stmt.close();
               return rs;
           } catch (SQLException ex) {
               ex.printStackTrace();
               return null;
           }
    	
    }
    
    
    public static ResultSet getTablaHistorico(int resultSetType, int resultSetConcurrency) throws SQLException {
    	
    	try {
    		Statement stmt = conn.createStatement(resultSetType, resultSetConcurrency);
    		ResultSet rs = stmt.executeQuery(DB_CLI_SELECT_ALL_HISTORICO + " ORDER BY " + DB_CLI_IDPARTIDA + " DESC");
    		//stmt.close();
    		return rs;
    	} catch (SQLException ex) {
    		ex.printStackTrace();
    		return null;
    	}
    	
    }


    /**
     * Obtiene toda la tabla Persona de la base de datos
     */
    public static ResultSet getTablaPersona() throws SQLException {
        return getTablaRanking(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
    }

    /**
     * Imprime por pantalla el contenido de la tabla Persona
     */
  public static void printTablaPersona() throws SQLException {
	  try {
          ResultSet rs = getTablaRanking(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
          while (rs.next()) {
              String n = rs.getString(DB_CLI_NICKNAME);
              int e = rs.getInt(DB_CLI_PUNTUACION);
//              Date f = rs.getDate(DB_CLI_FECN);
              System.out.println(n + "\t" + e + "\t" /*+ f*/);
          }
          rs.close();
      } catch (SQLException ex) {
          ex.printStackTrace();
      }
    }

    //////////////////////////////////////////////////
    // MÉTODOS DE UNA SOLA PERSONA
    //////////////////////////////////////////////////
    ;
    
    /**
     * Solicita a la BD la Persona con el nombre indicado
     */
    public static ResultSet getPersona(String nombre) {
        
    	try {
            // Realizamos la consulta SQL
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            String sql = DB_CLI_SELECT_ALL_RANKING + " WHERE " + DB_CLI_NICKNAME + "='" + nombre + "';";
            //System.out.println(sql);
            ResultSet rs = stmt.executeQuery(sql);
            //stmt.close();
            
            // Si no hay primer registro entonces no existe el persona
            if (!rs.first()) {
                return null;
            }

            // Todo bien, devolvemos el persona
            return rs;

        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
    	
    	
    }
    
    
    
    public static ResultSet getCPU(String nombre) {
        
    	try {
            // Realizamos la consulta SQL
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            String sql = DB_CLI_SELECT_NICK_PUNTUACION_HISTORICO;
            //System.out.println(sql);
            ResultSet rs = stmt.executeQuery(sql);
            //stmt.close();
            
            // Si no hay primer registro entonces no existe el persona
            if (!rs.first()) {
                return null;
            }

            // Todo bien, devolvemos el persona
            return rs;

        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
    	
    	
    }

    /**
     * Comprueba si en la BD existe la persona con el nombre indicado
     *
     */
    public static boolean existsPersona(String nombre) {
        
    	 try {
             // Obtenemos la persona
             ResultSet rs = getPersona(nombre);

             // Si rs es null, se ha producido un error
             if (rs == null) {
                 return false;
             }

             // Si no existe primer registro
             if (!rs.first()) {
                 rs.close();
                 return false;
             }

             // Todo bien, existe la persona
             rs.close();
             return true;

         } catch (SQLException ex) {
             ex.printStackTrace();
             return false;
         }
    }

 
  public static void printPersona(String nombre) {
        try {
            // Obtenemos el nombre de la persona
            ResultSet rs = getPersona(nombre);
            if (rs == null || !rs.first()) {
                System.out.println("Persona " + nombre + " NO EXISTE");
                return;
            }
            
            // Imprimimos su información por pantalla
            
            String nomb= rs.getString(DB_CLI_NICKNAME);
            int edad = rs.getInt(DB_CLI_PUNTUACION);
//            Date fecha = rs.getDate(DB_CLI_FECN);
            System.out.println("Persona " + nomb + "\t" + edad + "\t" /*+ fecha*/);

        } catch (SQLException ex) {
            System.out.println("Error al solicitar Persona" + nombre);
            ex.printStackTrace();
        }
    }

  
  
     public static boolean insertPersona(String nomb, int puntuacion) {
        try {

            System.out.println("Insertando persona " + nomb + "...");
            //MUY AL LORO CON LA SIGUIENTE LÍNEA Y COMO SE CONSTRUYE EL INSERT (COMILLAS SIMPLES PARA VARCHAR/DATE) 
            //El String debe estar muy fino. En mi BBDD la tabla Persona está escrita tal cual, así que al atacar
            //a esta tabla, hay que ir igual (P mayúscula inicial)
            String x ="INSERT INTO ranking(nickname,puntuacion) VALUES ('" + nomb + "'," + puntuacion + ")";
            System.out.println(x);
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            //EN LA VARIABLE NR ESTARIAN EL NÚMERO DE REGISTROS QUE SE HAN ACTUALIZADO.
            int nr = stmt.executeUpdate(x);

            return true;

        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
     
     
     public static boolean insertHistorico(int idPartida, String nomb, int puntuacion) {
         try {

             System.out.println("Insertando persona " + nomb + "...");
             //MUY AL LORO CON LA SIGUIENTE LÍNEA Y COMO SE CONSTRUYE EL INSERT (COMILLAS SIMPLES PARA VARCHAR/DATE) 
             //El String debe estar muy fino. En mi BBDD la tabla Persona está escrita tal cual, así que al atacar
             //a esta tabla, hay que ir igual (P mayúscula inicial)
             String x ="INSERT INTO historico(id_partida,nickname,puntuacion) VALUES (" + idPartida + ",'" + nomb + "'," + puntuacion + ")";
             System.out.println(x);
             Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
             //EN LA VARIABLE NR ESTARIAN EL NÚMERO DE REGISTROS QUE SE HAN ACTUALIZADO.
             int nr = stmt.executeUpdate(x);

             return true;

         } catch (SQLException ex) {
             ex.printStackTrace();
             return false;
         }
     }

    /**
     * Solicita a la BD modificar los datos de una persona
     *
     */
    public static boolean updatePuntuacionPersona(String nombre, int nuevaPuntuacion) {
       
    	try {

            System.out.println("Actualizando puntuacion de " + nombre + "...");
            //MUY AL LORO CON LA SIGUIENTE LÍNEA Y COMO SE CONSTRUYE EL INSERT (COMILLAS SIMPLES PARA VARCHAR/DATE)
            
            String x ="UPDATE ranking SET puntuacion = " + nuevaPuntuacion + " WHERE NOMBRE = '"+nombre+"';";
            System.out.println(x);
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
        	//EN LA VARIABLE NR ESTARIAN EL NÚMERO DE REGISTROS QUE SE HAN ACTUALIZADO.
            int nr = stmt.executeUpdate(x);

            return true;

        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    /**
     * Solicita a la BD eliminar una Persona
     */
    public static boolean deletePersona(String nombre) {
    	try {
            System.out.print("Eliminando persona " + nombre + "... ");

            // Obtenemos la persona
            ResultSet rs = getPersona(nombre);

            // Si no existe el Resultset
            if (rs == null) {
                System.out.println("ERROR. ResultSet null.");
                return false;
            }

            // Si existe y tiene primer registro, lo eliminamos
            if (rs.first()) {
                rs.deleteRow();
                rs.close();
                System.out.println("OK!");
                return true;
            } else {
                System.out.println("ERROR. ResultSet vacío.");
                return false;
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

}



