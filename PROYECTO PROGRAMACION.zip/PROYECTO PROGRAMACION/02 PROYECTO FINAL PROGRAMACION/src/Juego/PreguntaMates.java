package Juego;

import java.util.*;

import javax.swing.JOptionPane;

public class PreguntaMates extends Preguntas{
	
	private ArrayList<Character> simbolosEcuacion;
	private ArrayList<Object> ecuacion;
	private ArrayList<Integer> numerosEcuacion;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public PreguntaMates(int numeroSimbolos, Jugador jugadorPregunta) {
		super(numeroSimbolos, jugadorPregunta);
		this.numerosEcuacion = new ArrayList<Integer>();
		this.simbolosEcuacion = new ArrayList<Character>();
		this.ecuacion = new ArrayList<>();
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void generarPregunta() {
		JOptionPane.showMessageDialog(null, "Pregunta de MATEMATICAS para " + super.jugadorPregunta.nombre + "\n" + "\n" + "INFORMACIÓN: Se te mostrara una ecuación que tendras que resolver");
		
		
		
		//INSTANCE OFF DE PERSONA O CPU Y SI ES CPU NO MOSTRAR LA PREGUNTA SINO QUE SUMAR EL PUNTO DIRECTAMENTE
		if (super.jugadorPregunta instanceof CPU) {
			JOptionPane.showMessageDialog(null, "El jugador " + super.jugadorPregunta.nombre + " ha acertado la pregunta");
			this.jugadorPregunta.puntuacion++;
		} else if(super.jugadorPregunta instanceof Persona) {
			//GENERO NUMEROS ATLEATORIOS
			for (int i = 0; i < (super.numero+1); i++) {
				generarNumero();
			}
			//GENERO SIMBOLOS ATLEATORIOS
			for (int i = 0; i< super.numero; i++) {
				generarSimbolo();
			}
			//METO T0D0 EN UN MISMO ARRAY
			mezclar_num_simbolos();
			mostrarPregunta();
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public void generarNumero() {
		numerosEcuacion.add((int)((Math.random()*12))+1);
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void generarSimbolo() {
		int numeroSimbolo = (int) ((Math.random()*3)+1);
		switch (numeroSimbolo) {
		case(1):
			simbolosEcuacion.add('+');
		break;
		case(2):
			simbolosEcuacion.add('-');
		break;
		case(3):
			simbolosEcuacion.add('*');
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void mezclar_num_simbolos() {
		int j = 0;
		for (int i = 0; i < simbolosEcuacion.size(); i++) {
			ecuacion.add(numerosEcuacion.get(j));
			ecuacion.add(simbolosEcuacion.get(j));
			j++;
		}
		ecuacion.add(numerosEcuacion.get(j));
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void mostrarPregunta() {
		//CREO LA ECUACION EN STRING
		String ecuacionString = generarEcuacion();
		int respuestaRecibida = 0;
		
		int respuestaEsperada = calcularResultado();
		super.respuestaEsperada = String.valueOf(respuestaEsperada);
		try {
			String respuestaRecibidaString = JOptionPane.showInputDialog("La siguiente ecuacion a resolver es: " + "\n" + ecuacionString);
			if (respuestaRecibidaString.equals(null)) {
				throw new Exception();
			}
			respuestaRecibida = Integer.parseInt(respuestaRecibidaString);
			if (respuestaRecibida == respuestaEsperada) {
				JOptionPane.showMessageDialog(null, "Has acertado la pregunta");
				this.jugadorPregunta.puntuacion++;
			} else {
				JOptionPane.showMessageDialog(null, "Lo siento, la respuesta es incorrecta, la respuesta correcta era: " + super.respuestaEsperada);
			}	
		} catch(NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "Dato introducido no valido, inserte un numero");
				mostrarPregunta();
		} catch(Exception e) {
			int opcion = JOptionPane.showOptionDialog(null, "¿Quieres salir de la partida? (NO SE GUARDARA EL PROGRESO DE ESTA)", "SALIR DE LA PARTIDA", JOptionPane.YES_NO_CANCEL_OPTION, -1, null, new String[] {"Si","No"}, null);
			if (opcion == 0) {
				Partida.partidaFinaliza = false;
			} else {
				mostrarPregunta();
			}
		}
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public String generarEcuacion() {
		String ecuacionString = "";
		for (int i = 0; i<ecuacion.size(); i++) {
			ecuacionString = ecuacionString + String.valueOf(ecuacion.get(i));
		}
		return ecuacionString;
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public int calcularResultado() {
		ArrayList<Object> copiaEcuacion = new ArrayList<Object>(ecuacion);
		while (copiaEcuacion.size() != 1) {
			int posicionMult = -1;
			int posicionSuma = -1;
			int posicionResta = -1;
			for (int i = 0; i < copiaEcuacion.size(); i++) {
				if (copiaEcuacion.get(i).equals('*')) {
					posicionMult = i;
				}
			}
			if (posicionMult != -1) {
				int operacion = ((int) (copiaEcuacion.get(posicionMult - 1))) * (int) (copiaEcuacion.get(posicionMult + 1));
				copiaEcuacion.remove(posicionMult+1);
				copiaEcuacion.remove(posicionMult);
				copiaEcuacion.remove(posicionMult-1);
				copiaEcuacion.add((posicionMult - 1), operacion);
				posicionMult = -1;
			} else {
				for (int i = 0; i < copiaEcuacion.size(); i++) {
					if (copiaEcuacion.get(i).equals('+')) {
						posicionSuma = i;
						break;
					} else if (copiaEcuacion.get(i).equals('-')) {
						posicionResta = i;
						break;
					}
				}
				if (posicionSuma != -1) {
					int operacion = ((int) (copiaEcuacion.get(posicionSuma - 1))) + (int) (copiaEcuacion.get(posicionSuma + 1));
					copiaEcuacion.remove(posicionSuma+1);
					copiaEcuacion.remove(posicionSuma);
					copiaEcuacion.remove(posicionSuma-1);
					copiaEcuacion.add((posicionSuma - 1), operacion);
					posicionSuma = -1;
				} else if (posicionResta != -1){
					int operacion = ((int) (copiaEcuacion.get(posicionResta - 1))) - (int) (copiaEcuacion.get(posicionResta + 1));
					copiaEcuacion.remove(posicionResta+1);
					copiaEcuacion.remove(posicionResta);
					copiaEcuacion.remove(posicionResta-1);
					copiaEcuacion.add((posicionResta - 1), operacion);
					posicionResta = -1;
				}
			}
		}
		int resultado = (int) copiaEcuacion.get(0);
		return resultado;
//		System.out.println(ecuacion);
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
}
