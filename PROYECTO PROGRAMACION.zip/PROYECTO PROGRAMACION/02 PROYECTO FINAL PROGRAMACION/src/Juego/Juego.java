package Juego;

import javax.swing.JOptionPane;

public class Juego {
	static int seleccion;
	public static void main(String[] args) {
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//		CREACION DE VARIABLES	
		Ranking rankingJugadores = new Ranking();
		boolean driverCargado = DBManager.loadDriver();
		boolean conectaBBDD = DBManager.connect();
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		if(driverCargado && conectaBBDD) {
			seleccion = Menu.menuJuego();
			while ((seleccion != 4 && seleccion != -1)) {
				if (seleccion == 0) {
					
					int opcionPartida = JOptionPane.showOptionDialog(null, "Dime que tipo de partida que quieres jugar", "SELECCIONA TIPO DE PARTIDA", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, new String[]{"Partida", "Práctica", "Info"}, null);
					switch (opcionPartida) {
						case 0: {
							JOptionPane.showMessageDialog(null, "Has elegido partida");
							String tipoPartida = "Partida";
							Partida partida = new Partida(tipoPartida);
							partida.jugarPartida();
							seleccion = Menu.menuJuego();
							break;
						}
						case 1: {
							JOptionPane.showMessageDialog(null, "Has elegido Practica");
							String tipoPartida = "Practica";
							Partida partida = new Partida(tipoPartida);
							partida.jugarPartida();
							seleccion = Menu.menuJuego();
							break;
						}
						case 2: {
							Partida.infoPartida();
							seleccion = Menu.menuJuego();
							break;
						}
						default: {
							seleccion = Menu.menuJuego();
							break;
						}
					}
					
				} else if (seleccion == 1) {//RANKING
					
					rankingJugadores.mostrarRankingJugadores();
					seleccion = Menu.menuJuego();
					
				} else if (seleccion == 2) {//HISTORICO
					
					rankingJugadores.mostrarRankingHistorico();
					seleccion = Menu.menuJuego();
					
				} else if (seleccion == 3) {//JUGADORES
					int nCrearEliminar = Menu.crearEliminarOpcion();
					if (nCrearEliminar == 0) {//CREAR JUGADOR
						String nombreJugador = JOptionPane.showInputDialog(null, "Dime el nombre del jugador que quieres añadir (RECUERDA QUE NO PUEDE TENER ESPACIOS EN BLANCO)8");
						if (nombreJugador == null || nombreJugador.equals(null) || nombreJugador.equals("") || nombreJugador.equals(" ")) {
							seleccion = Menu.menuJuego();
						} else {
							Jugador jugador1 = new Persona(nombreJugador, 0);
							jugador1.crearJugador();
							seleccion = Menu.menuJuego();
						}
					} else if (nCrearEliminar == 1) {//ELIMINAR JUGADOR
						String nombreJugador = JOptionPane.showInputDialog(null, "Dime el nombre del jugador que quieres eliminar");
						if (nombreJugador == null) {
							seleccion = Menu.menuJuego();
						} else {
							int confirmarEliminar = Menu.confirmarEliminar(nombreJugador);
							if (confirmarEliminar == 0) {
								Jugador jugador2 = new Persona(nombreJugador, 0);
								((Persona) jugador2).eliminarJugador();
								seleccion = Menu.menuJuego();
							} else {
								seleccion = Menu.menuJuego();
							}
						}
					} else if (nCrearEliminar == 2) {
						Ranking.mostrarJugadores();
					} else if (nCrearEliminar == -1) {
						seleccion = Menu.menuJuego();
					}
				} else if (seleccion == 4) {
					JOptionPane.showMessageDialog(null, "HASTA LUEGO :D");
					DBManager.close();
				}
			}
			DBManager.close();
		}
	}
}
