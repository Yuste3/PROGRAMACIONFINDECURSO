package Juego;

import java.io.File;
import java.io.FileWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class Ranking {
	File rankingJugadores;
	File rankingHistorico;
	Scanner scJugadores;
	Scanner scHistorico;
	FileWriter inputJugadores;
	FileWriter inputHistorico;
	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public Ranking() {
		this.rankingJugadores = new File("src/Juego/rankingJugadores");
		this.rankingHistorico = new File("src/Juego/rankingHistorico");
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void mostrarRankingJugadores() {
		String rJugadoresString = "";
		ResultSet rs;
		try {
			rs = DBManager.getTablaRanking(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			while (rs.next()) {
				rJugadoresString = rJugadoresString + rs.getString("nickname") + " " + rs.getInt("puntuacion") + "\n";
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		JOptionPane.showMessageDialog(null, "EL RANKING ES EL SIGUIENTE: " + "\n" + "\n" + rJugadoresString, "RANKING JUGADORES", -1);
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void mostrarRankingHistorico() {
		String rankingHistoricoString = actualizarRankingHistorico();
		JOptionPane.showMessageDialog(null, "El ranking Historico es el siguiente:" + "\n" + "\n" + rankingHistoricoString + "\n");
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public String actualizarRankingHistorico() {
		ArrayList<String> rankingHistoricoArray = new ArrayList<String>();
		
		try {
			int idPartidaRonda = 0;
			String datosParaArray = "";
			ResultSet rs = DBManager.getTablaHistorico(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			rs.next();
			idPartidaRonda = rs.getInt("id_partida");
			rs.last();
			rs.first();
			while (rs.next()) {
				int idPartida = rs.getInt("id_partida");
				if (idPartida != idPartidaRonda) {
					idPartidaRonda = idPartida;
					rankingHistoricoArray.add(datosParaArray);
					datosParaArray = "";
				}
				String nombre = rs.getString("nickname");
				String puntuacion = String.valueOf(rs.getInt("puntuacion"));
				datosParaArray = datosParaArray + nombre + " " + puntuacion + " ";
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		String datosRanking = "";
		for (String datos : rankingHistoricoArray) {
			datosRanking = datosRanking + datos + "\n";
		}
		return datosRanking;
		
	}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static void mostrarJugadores() {
		String nombresJugadores = "";
		try {
			ResultSet rs = DBManager.getTablaRanking(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			while (rs.next()) {
				nombresJugadores = nombresJugadores + rs.getString("nickname") + "\n";
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		JOptionPane.showMessageDialog(null, "JUGADORES RESGISTRADOS EN EL SISTEMA:" + "\n" + "\n" + nombresJugadores);
	}

}
